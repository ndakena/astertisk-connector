from . import phone_validation_mixin
from . import res_company
from . import res_partner
from . import phone_common
